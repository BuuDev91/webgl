const c = WebGL2RenderingContext.ACTIVE_ATTRIBUTES;
console.log(c);
